#include <stdio.h>

int main() {
    int n,cnt=0;
    char str[100];
    scanf("%d\n%s",&n,str);
    for (int i = 0; i < n; ++i) {
        if(str[i]=='Q'){
            for (int j = i+1; j < n; ++j) {
                if(str[j]=='A'){
                    for (int k = j+1; k < n; ++k) {
                        if(str[k]=='Q')
                            cnt++;
                    }
                }
            }
        }
    }
    printf("%d",cnt);
    return 0;
}