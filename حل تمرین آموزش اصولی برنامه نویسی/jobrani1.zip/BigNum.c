#include <stdio.h>
#include <string.h>
int main() {
    char num1[100];
    char num2[100];
    char result[200];
    int sign=1;

    scanf("%s %s",num1,num2);

    if(num1[0]=='-'){
        sign=sign*-1;
        strcpy(num1,&num1[1]);
    }else if(num1[0]=='+'){
        strcpy(num1,&num1[1]);
    }

    if(num2[0]=='-'){
        sign=sign*-1;
        strcpy(num2,&num2[1]);
    }else if(num2[0]=='+'){
        strcpy(num2,&num2[1]);
    }

    for (int i = 0; i <200; ++i) {
        result[i]='0';
    }
    int index_shift=0;

    for (int j = strlen(num2)-1 ; j >=0; --j) {
        int a=num2[j]-'0';
        int carry=0;
        int index=0;
        for (int i = strlen(num1)-1; i >=0; --i) {
            int b=num1[i]-'0';
            int sum=a*b+carry+result[index+index_shift]-'0';
            carry=sum/10;
            result[index+index_shift]=(sum%10)+'0';
            index++;

        }
        if(carry>0){
            result[index+index_shift]=carry+'0';
        }
        index_shift++;
    }
    int index_zero;
    for (index_zero = 199; result[index_zero]=='0'  && index_zero>-1 ; --index_zero) ;
    if(index_zero==-1)
        result[1]='\0';
    else
        result[index_zero+1]='\0';
    strrev(result);

    if(sign==-1 && result[0]!='0')
        printf("-");
    printf("%s",result);


    return 0;
}