#include <stdio.h>
int main()
{
    int i = 0;
    switch (i)
    {
        case '0': printf("C++");

        case '1': printf("C");
                break;
        default: printf("Java");
    }
    return 0;
} 
