#include<stdio.h>

int &fun()
{
    static int x = 10;
    return x;
}

int main()
{
    fun() = 30;
    printf("%d",fun());
    return 0;
}