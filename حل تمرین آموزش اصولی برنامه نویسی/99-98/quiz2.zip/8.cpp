#include <stdio.h>

 
int fun(int x = 0, int y = 0, int z)
{
  return (x + y + z);
}
 
int main()
{
   printf("%d",fun(10));
   return 0;
}
