#include <stdio.h>
int main(){
	char *str = "abcde";
	str++;
	printf("%s", str);
	return 0;
}
