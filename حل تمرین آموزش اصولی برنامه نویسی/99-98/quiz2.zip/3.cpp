#include <stdio.h>
int main()
{
 char *ptr = "Ferdowsi";
 printf("%c\n", *&*&*ptr);
 return 0;
}
