#include <stdio.h>

int var = 20;

int main()
{
    int var = var;
    printf("%d ", var);
    return 0;
}


