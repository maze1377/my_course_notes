#include<stdio.h>

void swap (char *x, char *y)
{
    char *temp = x;
    x = y;
    y = temp;
}

int main()
{
    char *x = "Saeid";
    char *y = "Abrishami";
    char *temp;
    swap(x, y);
    printf("%s, %s", x, y);
    temp = x;
    x = y;
    y = temp;
    printf("\n%s, %s", x, y);
    return 0;
}
