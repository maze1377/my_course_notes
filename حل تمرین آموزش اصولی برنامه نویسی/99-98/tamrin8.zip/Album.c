#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct User {
    char name[20];
    int age;
    char city[20];
    int albums_num;
    char albums[20][20];
};

struct Album {
    char name[20];
    char singer[20];
    char genre[20];
    int tracks;
};

int n, m, q;
struct User users[100];
struct Album albums[100];

int find_user(char user_name[]) {
    int i;
    for (i = 0; i < n; i++) {
        if (strcmp(users[i].name, user_name) == 0) {
            return i;
        }
    }
    return -1;
}

int find_album(char album_name[]) {
    int i;
    for (i = 0; i < m; i++) {
        if (strcmp(albums[i].name, album_name) == 0) {
            return i;
        }
    }
    return -1;
}

int request(int type, char in1[], char in2[]) {
    int i, j;
    int user_i = -1;
    int album_i = -1;
    int age = -1;
    int tracks = 0;
    switch (type) {
    case 1:
        user_i = find_user(in1);
        if (user_i == -1) return 0;
        else {
            for (i = 0; i < users[user_i].albums_num; i++) {
                album_i = find_album(users[user_i].albums[i]);
                if (strcmp(albums[album_i].singer, in2) == 0)
                    tracks += albums[album_i].tracks;
            }
            return tracks;
        }
        break;
    case 2:
        user_i = find_user(in1);
        if (user_i == -1) return 0;
        else {
            for (i = 0; i < users[user_i].albums_num; i++) {
                album_i = find_album(users[user_i].albums[i]);
                if (strcmp(albums[album_i].genre, in2) == 0)
                    tracks += albums[album_i].tracks;
            }
            return tracks;
        }
        break;
    case 3:
        age = atoi(in1);
        for (i = 0; i < n; i++) {
            if (users[i].age == age) {
                for (j = 0; j < users[i].albums_num; j++) {
                    album_i = find_album(users[i].albums[j]);
                    if (strcmp(albums[album_i].singer, in2) == 0)
                        tracks += albums[album_i].tracks;
                }
            }
        }
        return tracks;
    case 4:
        age = atoi(in1);
        for (i = 0; i < n; i++) {
            if (users[i].age == age) {
                for (j = 0; j < users[i].albums_num; j++) {
                    album_i = find_album(users[i].albums[j]);
                    if (strcmp(albums[album_i].genre, in2) == 0)
                        tracks += albums[album_i].tracks;
                }
            }
        }
        return tracks;
    case 5:
        for (i = 0; i < n; i++) {
            if (strcmp(users[i].city, in1) == 0) {
                for (j = 0; j < users[i].albums_num; j++) {
                    album_i = find_album(users[i].albums[j]);
                    if (strcmp(albums[album_i].singer, in2) == 0)
                        tracks += albums[album_i].tracks;
                }
            }
        }
        return tracks;
    case 6:
        for (i = 0; i < n; i++) {
            if (strcmp(users[i].city, in1) == 0) {
                for (j = 0; j < users[i].albums_num; j++) {
                    album_i = find_album(users[i].albums[j]);
                    if (strcmp(albums[album_i].genre, in2) == 0)
                        tracks += albums[album_i].tracks;
                }
            }
        }
        return tracks;
    }
    return 0;
}

int main()
{
    int i, j;
    char tmp[20];
    int type, ans[100];
    char in1[20], in2[20];
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%s", tmp);
        scanf("%s", users[i].name);
        scanf("%s", tmp);
        scanf("%d", &users[i].age);
        scanf("%s", tmp);
        scanf("%s", users[i].city);
        scanf("%s", tmp);
        scanf("%d", &users[i].albums_num);
        for (j = 0; j < users[i].albums_num; j++) {
            scanf("%s", users[i].albums[j]);
        }
    }
    scanf("%d", &m);
    for (i = 0; i < m; i++) {
        scanf("%s", tmp);
        scanf("%s", albums[i].name);
        scanf("%s", tmp);
        scanf("%s", albums[i].singer);
        scanf("%s", tmp);
        scanf("%s", albums[i].genre);
        scanf("%s", tmp);
        scanf("%d", &albums[i].tracks);
    }
    scanf("%d", &q);
    for (i = 0; i < q; i++) {
        scanf("%d", &type);
        scanf("%s", in1);
        scanf("%s", in2);
        ans[i] = request(type, in1, in2);
    }

    for (i = 0; i < q; i++) {
        printf("%d\n", ans[i]);
    }
    return 0;
}
