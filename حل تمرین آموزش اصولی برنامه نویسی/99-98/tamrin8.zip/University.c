#include <stdio.h>
#include <string.h>

struct Grade {
	char student_id[21];
	char course_id[21];
	float grade;
};

int grade_count;
struct Grade grades[200];

void search(int type, char id[21]) {
	int i;
	if (type == 1)
		for (i = 0; i < grade_count; i++)
			if (strcmp(grades[i].student_id, id) == 0)
				printf("%s %.2f\n", grades[i].course_id, grades[i].grade);
	if (type == 2)
		for (i = 0; i < grade_count; i++)
			if (strcmp(grades[i].course_id, id) == 0)
				printf("%s %.2f\n", grades[i].student_id, grades[i].grade);
}


void main() {
	char command[20];
	int students_count = 0;
	char students[200][21];
	int courses_count = 0;
	char courses[200][21];
	while (1) {
		scanf("%s", command);
		if (strcmp(command, "ADD") == 0) {
			char type[20];
			while (1) {
				scanf("%s", type);
				if (strcmp(type, "END") == 0) break;
				else if (strcmp(type, "STUDENT") == 0) {
					scanf("%s", students[students_count]);
					students_count++;
				}
				else if (strcmp(type, "COURSE") == 0) {
					scanf("%s", courses[courses_count]);
					courses_count++;
				}
			}
		}
		else if (strcmp(command, "GRADE") == 0) {
			char course[21];
			while (1) {
				scanf("%s", course);
				if (strcmp(course, "END") == 0) break;
				strcpy(grades[grade_count].course_id, course);
				scanf("%s %f", grades[grade_count].student_id, &grades[grade_count].grade);
				grade_count++;
			}
		}
		else if (strcmp(command, "STATS") == 0) {
			char type[20], id[21];
			while (1) {
				scanf("%s", type);
				if (strcmp(type, "END") == 0) break;
				else if (strcmp(type, "STUDENT") == 0) {
					scanf("%s", id);
					search(1, id);
				}
				else if (strcmp(type, "COURSE") == 0) {
					scanf("%s", id);
					search(2, id);
				}
			}
		}
		else
			break;
	}

}