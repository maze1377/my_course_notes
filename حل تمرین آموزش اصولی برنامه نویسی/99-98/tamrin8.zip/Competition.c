#include <stdio.h>
#include <string.h>

struct User {
	char name[20];
	int first;
	int last;
	int seen;
};

struct Event {
	int day;
	char time[20];
	int user_id;
};

struct Day {
	int day;
	int eventsCount;
	struct Event events[100];
};

int n, d;
int user_count = 0;
struct Day days[100];
struct User users[100];

void calc_report(int day) {
	int totalCount = 0, firstCount = 0, lastCount = 0;
	int i;
	for (i = 0; i < days[day - 1].eventsCount; i++) {
		users[days[day - 1].events[i].user_id].seen = 0;
	}
	for (i = 0; i < days[day-1].eventsCount; i++) {
		if (users[days[day - 1].events[i].user_id].seen == 0) {
			if (users[days[day - 1].events[i].user_id].first == day)
				firstCount += 1;
			if (users[days[day - 1].events[i].user_id].last == day)
				lastCount += 1;
			totalCount += 1;
			users[days[day - 1].events[i].user_id].seen = 1;
		}
	}
	printf("%d %d %d\n", totalCount, firstCount, lastCount);
}

int find_user(char name[20]) {
	int i = 0;
	for (i = 0; i < user_count; i++) {
		if (strcmp(name, users[i].name) == 0)
			return i;
	}
	return -1;
}

void main() {
	
	scanf("%d %d", &n, &d);
	int i, user_index;

	for (i = 0; i < n; i++) {
		struct Event event;
		char tmp[20];
		char name[20];
		scanf("%s day: %d | time: %s | name: %s ]", tmp, &event.day, event.time, name);
		user_index = find_user(name);
		if (user_index == -1) {
			strcpy(users[user_count].name, name);
			users[user_count].first = event.day;
			users[user_count].last = event.day;
			event.user_id = user_count;
			user_count++;
		}
		else {
			users[user_index].last = event.day;
			event.user_id = user_index;
		}
		days[event.day - 1].day = event.day;
		days[event.day - 1].events[days[event.day - 1].eventsCount] = event;
		days[event.day - 1].eventsCount++;
	}

	for (i = 1; i <= d; i++)
		calc_report(i);
}