#include<stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    int remaining = n % 4;
    int div = n / 4;
    int x, y;
    if (remaining == 0) {
        x = -div;
        y = div;
    } else if (remaining == 1) {
        x = y = -div;
    } else if (remaining == 2) {
        x = div + 1;
        y = -div;
    } else {
        x = y = div + 1;
    }

    printf("%d %d", x, y);
    return 0;
}