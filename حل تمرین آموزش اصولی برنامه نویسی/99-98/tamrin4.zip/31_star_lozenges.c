#include<stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    int temp = 0;
    int half = n / 2 + 1;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= 2*n; j++) {
            if((j >= half - temp && j <= half + temp) || (j >= n + half - temp && j <= n + half + temp)) {
                printf("*");
            } else printf(" ");
        }
        printf("\n");

        if(i < half) {
            temp++;
        } else temp--;
    }
    return 0;
}