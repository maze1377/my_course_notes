#include<stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    int temp = n;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            if(i == 1 || i == n || j == 1 || j == n || i == j || j == n - i + 1 || j >= temp)
                printf("#");
            else printf(" ");
        }
        printf("\n");
        if(i <= n/2)
            temp--;
        else temp++;
    }
}