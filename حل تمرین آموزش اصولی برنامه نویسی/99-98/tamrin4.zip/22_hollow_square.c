#include<stdio.h>

int main() {
    int a, b;
    scanf("%d %d", &a, &b);
    if(b >= a) {
        printf("Wrong order!");
        return 0;
    }
    if((b-a) % 2 != 0) {
        printf("Wrong difference!");
        return 0;
    }
    int offset = (a - b) / 2;
    for (int i = 1; i <= a; i++) {
        for (int j = 1; j <= a; j++) {
            if(i > offset && i <= a - offset && j > offset && j <= a - offset) {
                printf("  ");
            } else printf("* ");
        }
        printf("\n");
    }
    return 0;
}