#include <stdio.h>
#define MAX 102

int table[MAX][MAX] = { 0 };

int countBombs(int row, int col) {
    int count = 0;

    for(int i = -1; i <= 1; i++) {
        for(int j = -1; j <= 1; j++) {
            if(table[row + i][col + j] == -1) count++;
        }
    }

    return count;
}

int main() {
    int row, col, bombCount;
    scanf("%d %d %d", &row, &col, &bombCount);

    int y, x;
    for(int i = 0; i < bombCount; i++) {
        scanf("%d %d", &y, &x);
        table[y][x] = -1;
    }

    for(int i = 1; i <= row; i++) {
        for(int j = 1; j <= col; j++) {
            if(table[i][j] == -1) {
                printf("* ");
            } else {
                printf("%d ", countBombs(i, j));
            }
        }
        printf("\n");
    }

}