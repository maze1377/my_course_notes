#include <stdio.h>
#define SIZE 9

int main() {
    int table[SIZE][SIZE];

    for(int i = 0; i < SIZE; i++) {
        for(int j = 0; j < SIZE; j++) {
            scanf("%d", &table[i][j]);
        }
    }

    int row, col;
    scanf("%d %d", &row, &col);
    row--, col--;

    int numbers[10] = { 0 };

    for(int i = 0; i < SIZE; i++) {
        int number = table[row][i];
        numbers[number] = 1;
    }

    for(int i = 0; i < SIZE; i++) {
        int number = table[i][col];
        numbers[number] = 1;
    }

    int rowStart = (row / 3) * 3;
    int colStart = (col / 3) * 3;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            int number = table[rowStart + i][colStart + j];
            numbers[number] = 1;
        }
    }

    int count = 0;
    int result;
    for(int i = 1; i <= 9; i++) {
        if(numbers[i] == 0) {
            count++;
            result = i;
        }
    }

    if(count == 1)
        printf("%d", result);
    else
        printf("unknown");
}
