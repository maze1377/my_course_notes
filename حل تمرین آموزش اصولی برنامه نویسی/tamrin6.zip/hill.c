#include <stdio.h>
#include <string.h>
#define MAX 71

int isHeidari(char number[]) {
    int isAsc = 1;
    int changeCounter = 0;

    int length = strlen(number);

    for(int i = 0; i < length - 1; i++) {
        if(number[i] > number[i + 1] && isAsc) {
            isAsc = 0;
            changeCounter++;
        } else if(number[i] < number[i + 1] && !isAsc) {
            isAsc = 1;
            changeCounter++;
        }
    }

    return changeCounter <= 1;
}

int main() {
    int count;
    scanf("%d", &count);

    char number[MAX];
    for(int i = 0; i < count; i++) {
        scanf("%s", number);

        if(isHeidari(number)) {
            printf("%s\n", number);
        } else {
            printf("-1\n");
        }
    }
}