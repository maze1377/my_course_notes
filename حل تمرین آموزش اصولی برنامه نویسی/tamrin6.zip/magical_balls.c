#include <stdio.h>
#include <math.h>
#define MAX 50

int isSquared(int number) {
    return floor(sqrt(number)) == sqrt(number);
}

int main() {
    int rods[MAX] = { 0 };

    int n;
    scanf("%d", &n);

    int ball = 1;
    for (int i = 0; i < n; ++i) {
        if(isSquared(rods[i] + ball) || rods[i] == 0) {
            rods[i] = ball;
            ball++;
            i = -1;
        } else if(i == n - 1) break;
    }

    printf("%d", ball - 1);
}