#include <stdio.h>

int calc(int i, int j) {
    if(i == 0 || j == 0) return 0;
    if(i == 1 && j == 1) return 1;
    return calc(i - 1, j - 1) + calc(i - 1, j);
}

int main() {
    int i = 7, j = 5;
    printf("%d", calc(i, j));
}
