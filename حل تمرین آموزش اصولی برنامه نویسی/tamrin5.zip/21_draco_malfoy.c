#include<stdio.h>
#include <math.h>

int isPrime(int number) {
    int root = sqrt(number);
    for (int i = 2; i <= root; i++) {
        if (number % i == 0) {
            return 0;
        }
    }
    return 1;
}

int isLuckyNumber(int number) {
    int count = 0;

    for (int i = 2; i < number; i++) {
        if (number % i == 0 && isPrime(i)) {
            count++;
            if (count >= 3)
                return 1;
        }
    }

    return 0;
}

int getNthLuckyNumber(int n) {
    int count = 0, i;
    for (i = 30; count < n; i++) {
        if (isLuckyNumber(i))
            count++;
    }
    return i - 1;
}

int main() {
    int n = 2;
    printf("%d", getNthLuckyNumber(n));
}
