#include <stdio.h>
#include <math.h>

int getSum(int number) {
    int sum = 0;
    while (number > 0) {
        sum += number % 10;
        number /= 10;
    }
    return sum;
}

int isPrime(int number) {
    int root = sqrt(number);
    for (int i = 2; i <= root; i++) {
        if (number % i == 0) {
            return 0;
        }
    }
    return 1;
}

int solve(int n) {
    int b = getSum(n);
    int count = 0;
    int i;
    for (i = n + 1; count < b; i++) {
        if (isPrime(i)) {
            count++;
        }
    }
    return i - 1;
}

int main() {
    int n = 100;
    printf("%d", solve(n));
}
