#include<stdio.h>
#include<math.h>

int isSquare(int number) {
    return sqrt(number) == floor(sqrt(number));
}

int isBeautiful(int number) {
    if(!isSquare(number)) return 0;
    for(int i = 4; i < number; i++) {
        if(number % i == 0 && isSquare(i))
            return 1;
    }
    return 0;
}

int isVeryBeautiful(int number) {
    if(!isBeautiful(number)) return 0;

    int degree = 0;
    for(int i = 2; i < number; i++) {
        if(number % i == 0 && isBeautiful(i)) {
            degree++;
            if(degree >= 3) {
                return 1;
            }
        }
    }

    return 0;
}

int countVeryBeautifulNumbers(int start, int end) {
    int count = 0;
    for(int i = start; i <= end; i++) {
        if(isVeryBeautiful(i))
            count++;
    }
    return count;
}

int main() {
    int a = 600, b = 4000;
    printf("%d", countVeryBeautifulNumbers(a, b));
}
