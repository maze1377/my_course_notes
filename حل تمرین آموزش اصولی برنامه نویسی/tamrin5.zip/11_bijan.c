#include<stdio.h>
#define MAX 1000

float glasses[MAX] = {0};

int getIndex(int i, int j) {
    return i * (i - 1) / 2 + j;
}

void fill(float volume, int i, int j) {
    if (volume == 0) return;

    int index = getIndex(i, j);

    glasses[index] += volume;
    volume = 0;
    if (glasses[index] > 1) {
        volume = glasses[index] - 1;
        glasses[index] = 1;
    }

    fill(volume / 2, i + 1, j);
    fill(volume / 2, i + 1, j + 1);
}

int main() {
    float volume = 15;
    int i = 4, j = 1;

    fill(volume, 1, 1);

    int wantedIndex = getIndex(i, j);
    printf("%.2f", glasses[wantedIndex]);
}
