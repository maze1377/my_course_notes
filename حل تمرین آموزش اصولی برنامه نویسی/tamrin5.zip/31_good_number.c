#include<stdio.h>

int countDivisions(int number) {
    int count = 0;
    for(int i = 1; i <= number; i++) {
        if(number % i == 0) {
            count++;
        }
    }
    return count;
}

int findGoodNumber(int k) {
    int good = 0;
    for(int i = 1; ; i++) {
        good += i;
        if(countDivisions(good) >= k)
            return good;
    }
}

int main() {
    int k;
    scanf("%d", &k);
    printf("%d", findGoodNumber(k));
}
